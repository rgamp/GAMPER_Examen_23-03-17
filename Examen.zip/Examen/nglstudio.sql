-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 23 Mars 2017 à 15:13
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `nglstudio`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id_client` int(11) NOT NULL,
  `info_client` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`id_client`, `info_client`) VALUES
(1, 'Client AAAAAAAAAAAAAAAAAAAAAAA AAAAAAAAAAAAAAA AAAAAAAAAAAAAA AAAAAAAAAAAAAAA AAAAAAAAAAAAAA'),
(2, 'Client BBBBBBBBBBB BBBBBBBBBBBBBB BBBBBBBBBBBBBBBB BBBBBBBBBBBBBB BBBBBBBBBBBBBBBBBBBB');

-- --------------------------------------------------------

--
-- Structure de la table `planification`
--

CREATE TABLE `planification` (
  `id_plani` int(11) NOT NULL,
  `date_crea_proj` date DEFAULT NULL,
  `date_fin_proj` date DEFAULT NULL,
  `projet_id_proj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `planification`
--

INSERT INTO `planification` (`id_plani`, `date_crea_proj`, `date_fin_proj`, `projet_id_proj`) VALUES
(1, '2017-03-01', '2017-04-01', 1);

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE `projet` (
  `id_proj` int(11) NOT NULL,
  `nom_proj` text,
  `nature_proj` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `projet`
--

INSERT INTO `projet` (`id_proj`, `nom_proj`, `nature_proj`) VALUES
(1, 'Projet A', 'Jeu');

-- --------------------------------------------------------

--
-- Structure de la table `propose`
--

CREATE TABLE `propose` (
  `id_client` int(11) NOT NULL,
  `id_proj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `propose`
--

INSERT INTO `propose` (`id_client`, `id_proj`) VALUES
(2, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ressources`
--

CREATE TABLE `ressources` (
  `id_ressource` int(11) NOT NULL,
  `logiciel` text,
  `budget_util` int(11) DEFAULT NULL,
  `nb_dessus` int(11) DEFAULT NULL,
  `projet_id_proj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `ressources`
--

INSERT INTO `ressources` (`id_ressource`, `logiciel`, `budget_util`, `nb_dessus`, `projet_id_proj`) VALUES
(2, 'Unity', 10000, 5, 1);

-- --------------------------------------------------------

--
-- Structure de la table `synthese`
--

CREATE TABLE `synthese` (
  `id_synthese` int(11) NOT NULL,
  `note_synthese` text,
  `id_proj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `synthese`
--

INSERT INTO `synthese` (`id_synthese`, `note_synthese`, `id_proj`) VALUES
(1, 'ça marche pas', 1);

-- --------------------------------------------------------

--
-- Structure de la table `travaille`
--

CREATE TABLE `travaille` (
  `id_user` int(11) NOT NULL,
  `id_proj` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `travaille`
--

INSERT INTO `travaille` (`id_user`, `id_proj`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nom_user` varchar(255) DEFAULT NULL,
  `password` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id_user`, `nom_user`, `password`) VALUES
(1, 'Gintoki', '*072CFC9D65DC5E28A54B5BF2F82379341CE03ECD'),
(2, 'Shinsuke', '*072CFC9D65DC5E28A54B5BF2F82379341CE03ECD'),
(3, 'Tatsuma', '*072CFC9D65DC5E28A54B5BF2F82379341CE03ECD');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id_client`);

--
-- Index pour la table `planification`
--
ALTER TABLE `planification`
  ADD PRIMARY KEY (`id_plani`),
  ADD KEY `FK_PLANIFICATION_projet_id_proj` (`projet_id_proj`);

--
-- Index pour la table `projet`
--
ALTER TABLE `projet`
  ADD PRIMARY KEY (`id_proj`);

--
-- Index pour la table `propose`
--
ALTER TABLE `propose`
  ADD PRIMARY KEY (`id_client`,`id_proj`),
  ADD KEY `FK_PROPOSE_id_proj` (`id_proj`);

--
-- Index pour la table `ressources`
--
ALTER TABLE `ressources`
  ADD PRIMARY KEY (`id_ressource`),
  ADD KEY `FK_RESSOURCES_projet_id_proj` (`projet_id_proj`);

--
-- Index pour la table `synthese`
--
ALTER TABLE `synthese`
  ADD PRIMARY KEY (`id_synthese`),
  ADD KEY `FK_SYNTHESE_id_proj` (`id_proj`);

--
-- Index pour la table `travaille`
--
ALTER TABLE `travaille`
  ADD PRIMARY KEY (`id_user`,`id_proj`),
  ADD KEY `FK_TRAVAILLE_id_proj` (`id_proj`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `planification`
--
ALTER TABLE `planification`
  MODIFY `id_plani` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `projet`
--
ALTER TABLE `projet`
  MODIFY `id_proj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `propose`
--
ALTER TABLE `propose`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `ressources`
--
ALTER TABLE `ressources`
  MODIFY `id_ressource` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `synthese`
--
ALTER TABLE `synthese`
  MODIFY `id_synthese` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `travaille`
--
ALTER TABLE `travaille`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `planification`
--
ALTER TABLE `planification`
  ADD CONSTRAINT `FK_PLANIFICATION_projet_id_proj` FOREIGN KEY (`projet_id_proj`) REFERENCES `projet` (`id_proj`);

--
-- Contraintes pour la table `propose`
--
ALTER TABLE `propose`
  ADD CONSTRAINT `FK_PROPOSE_id_client` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`),
  ADD CONSTRAINT `FK_PROPOSE_id_proj` FOREIGN KEY (`id_proj`) REFERENCES `projet` (`id_proj`);

--
-- Contraintes pour la table `ressources`
--
ALTER TABLE `ressources`
  ADD CONSTRAINT `FK_RESSOURCES_projet_id_proj` FOREIGN KEY (`projet_id_proj`) REFERENCES `projet` (`id_proj`);

--
-- Contraintes pour la table `synthese`
--
ALTER TABLE `synthese`
  ADD CONSTRAINT `FK_SYNTHESE_id_proj` FOREIGN KEY (`id_proj`) REFERENCES `projet` (`id_proj`);

--
-- Contraintes pour la table `travaille`
--
ALTER TABLE `travaille`
  ADD CONSTRAINT `FK_TRAVAILLE_id_proj` FOREIGN KEY (`id_proj`) REFERENCES `projet` (`id_proj`),
  ADD CONSTRAINT `FK_TRAVAILLE_id_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
